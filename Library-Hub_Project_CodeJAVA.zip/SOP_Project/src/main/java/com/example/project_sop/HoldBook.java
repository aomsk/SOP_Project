package com.example.project_sop;

import java.util.ArrayList;

public class HoldBook extends ArrayList<String> {

    public ArrayList<String> holdBookTitle = new ArrayList<String>();
    public ArrayList<String> searchBookTitleList = new ArrayList<String>();
    public ArrayList<String> searchBookISBNList = new ArrayList<String>();
    public ArrayList<String> searchBookAuthorList = new ArrayList<String>();
    public ArrayList<String> searchBookCategoriesList = new ArrayList<String>();

}
